-- NAME: MVRACPDnTap_svcloadstats.SQL
-- ------------------------------------------------------------------------
-- SOURCE:   Oracle Documentation
--
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The query displays the current load distribution across the various database services. 
-- The load characteristics are updated by MMON and can be viewed from GV$SERVICEMETRIC 
-- view
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 11 - Tuning SQL*Net
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set time on
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
column SERVICE_NAME format a20 truncated heading 'Service'
column INSTANCE_NAME heading 'Instance'  format a10
column SERVICE_TIME heading 'Service Time|Elapsed|mSec/Call' format 999999999
column CPU_TIME heading 'CPU Time |mSec/Call' format 999999999
column DB_TIME heading 'DB Time |mSec/Call' format 999999999
column THROUGHPUT heading 'Calls/sec' format 99999.99
column start_date format a26 heading "SrvMtric - start date"
break on SERVICE_NAME skip 1
SELECT SERVICE_NAME,
       INSTANCE_NAME,
       ELAPSEDPERCALL SERVICE_TIME,
       CPUPERCALL     CPU_TIME,
       DBTIMEPERCALL  DB_TIME,
       CALLSPERSEC    THROUGHPUT
FROM  GV$INSTANCE        GVI,
      GV$ACTIVE_SERVICES GVAS,
      GV$SERVICEMETRIC   GVSM
WHERE GVAS.INST_ID   = GVSM.INST_ID
AND   GVAS.NAME_HASH = GVSM.SERVICE_NAME_HASH
AND   GVI.INST_ID    = GVSM.INST_ID
AND   GVSM.GROUP_ID  = 10
AND   GVSM.SERVICE_NAME NOT IN ('SYS$BACKGROUND','SYS$USERS')
ORDER BY
   SERVICE_NAME,
   GVI.INST_ID;

