-- NAME: MVRACPDnTap_dgsynchcheck.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    URL: muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script is used to verify if the database is synchronized between the primary and 
-- the standby site.  Useful during a scheduled maintenance operation when the dataguard 
-- switchover operation is planned between the primary and standby site. 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 3
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
SET ECHO OFF
COL INST FORMAT 999
COL INSTN FORMAT A10
COL FFS FORMAT A16
COL FFCT FORMAT A7
COL FFT FORMAT 999
COL FOP FORMAT A4
COL FFOH FORMAT A20
COL DUN FORMAT  A6
COL DBR FORMAT A10
COL DGB FORMAT A10
SELECT GVD.INST_ID INST,
       GVI.INSTANCE_NAME INSTN,
       GVD.FS_FAILOVER_STATUS FFS,
       GVD.FS_FAILOVER_CURRENT_TARGET FFCT,
       GVD.FS_FAILOVER_THRESHOLD FFT,
       GVD.FS_FAILOVER_OBSERVER_PRESENT FFOP,
       GVD.OPEN_MODE OM,
       GVD.DB_UNIQUE_NAME DUN,
       GVD.DATABASE_ROLE DBR
FROM   GV$DATABASE GVD, GV$INSTANCE GVI
WHERE  GVD.INST_ID=GVI.INST_ID;

