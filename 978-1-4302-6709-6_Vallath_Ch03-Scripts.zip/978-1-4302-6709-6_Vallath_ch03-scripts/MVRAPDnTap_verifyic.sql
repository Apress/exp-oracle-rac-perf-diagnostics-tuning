-- NAME: MVRACPDnTap_verifyic.SQL
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    URL: muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- Scripts helps to list the interconnects configured and currently in use by the database for cache fusion activity. 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 3
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
SET ECHO OFF
COL NAME_KSXPIA FORMAT A10 heading "Name"
COL PUB_KSXPIA FORMAT A10  heading "Public"
COL PICKED_KSXPIA FORMAT A10 heading "Impl|Type"
COL INDX FORMAT 99999 heading "Indx"
COL INST_ID FORMAT 999 noprint
COL IP_KSXPIA FORMAT A15 heading "IP Address"
select * from x$ksxpia;

COL INST_ID FORMAT 999 heading "Instance" print
COL NAME FORMAT A10 Heading "Name"
COL SOURCE FORMAT A30 Heading "Source"
COL IP_ADDRESS FORMAT A15 Heading "IP Address"

SELECT *
FROM   gv$cluster_interconnects
ORDER  BY inst_id;  
