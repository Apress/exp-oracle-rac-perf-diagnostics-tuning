-- NAME: MVRACPDnTap_taftest.SQL
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    URL: muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 3
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR BREAKS
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
SET ECHO OFF
COL INT FORMAT 999
COL USERNAME FORMAT A14
COL SERVICE_NAME FORMAT A10
COL FT FORMAT A6
COL FO FORMAT A4
COL FAILED_OVER FORMAT A4
select to_char(sysdate,'Day mm/dd/rr hh24:mi') Start_date from dual;
--
break on INT skip 1
SELECT inst_id       INT,
       username,
       service_name,
       failover_method,
       failover_type "FT",
       failed_over   "FO",
       status,
       Count(*)
FROM   gv$session
WHERE  service_name NOT IN ( 'SYS$BACKGROUND','SYS$USERS')
       AND username IS NOT NULL
GROUP  BY inst_id,
          username,
          service_name,
          failover_method,
          failover_type,
          failed_over,
          status
ORDER  BY inst_id;  
