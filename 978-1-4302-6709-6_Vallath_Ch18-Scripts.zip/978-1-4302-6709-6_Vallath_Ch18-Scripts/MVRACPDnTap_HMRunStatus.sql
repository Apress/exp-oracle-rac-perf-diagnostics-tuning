-- NAME: MVRACPDnTap_HMRunStatus.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    Summersky Enterprises - www.summersky.biz
-- ------------------------------------------------------------------------
-- PURPOSE:
-- Script helps check the status of the various health monitor checks
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported by Summersky Enterprises.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 18 - Problem Diagnostics
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR BREAKS
set pagesize 60 space 2 numwidth 8 linesize 110 verify off
set pagesize 10000
COL INT FORMAT 99 heading "In"
COL NAME FORMAT A12
COL NI FORMAT 9999 heading "#inc"
COL SI FORMAT 9999 heading "SrcIn"
COL EN FORMAT 999 heading "Err"
COL CHECK_NAME FORMAT A28 TRUNC
COL END_TIME FORMAT A28
BREAK ON INT SKIP 1
SELECT  INST_ID INT    ,
        NAME           ,
        CHECK_NAME     ,
        RUN_MODE       ,
        STATUS         ,
--        END_TIME       ,
        SRC_INCIDENT SI,
        NUM_INCIDENT NI,
        ERROR_NUMBER EN
FROM    GV$HM_RUN
WHERE   RUN_MODE = 'REACTIVE'
ORDER BY INST_ID;
