-- NAME: MVRACPDnTap_adrincfiles.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    Summersky Enterprises - www.summersky.biz
-- ------------------------------------------------------------------------
-- PURPOSE:
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported by Summersky Enterprises.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 18 - Problem Diagnostics
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR breaks
set pagesize 60 SPACE 2 numwidth 8 linesize 110 verify OFF
set pagesize 10000
COL INT format 99 heading "In"
COL adr_home format a30 noprint
COL bfile format a70
BREAK ON adr_home skip 1
SELECT adr_home,
       bfile
FROM   v$diag_incident_file
ORDER  BY adr_home;  
