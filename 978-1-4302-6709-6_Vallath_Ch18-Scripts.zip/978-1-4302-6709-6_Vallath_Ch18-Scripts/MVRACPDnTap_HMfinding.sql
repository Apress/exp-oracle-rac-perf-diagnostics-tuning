-- NAME: MVRACPDnTap_HMfinding.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    Summersky Enterprises - www.summersky.biz
-- ------------------------------------------------------------------------
-- PURPOSE:
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported by Summersky Enterprises.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 18 - Problem Diagnostics
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR BREAKS
set pagesize 60 space 2 numwidth 8 linesize 110 verify off
set pagesize 10000
COL INT FORMAT 99 heading "In"
COL NAME FORMAT A24 trunc
COL FI FORMAT 99999 heading "Finding|id"
COL RI FORMAT 99999 heading "Run|id"
COL TIME_DETECTED FORMAT A28
COL STATUS FORMAT A8
COL TYPE FORMAT A8
BREAK ON INT SKIP 1

SELECT  FINDING_ID FI,
        RUN_ID RI    ,
        NAME         ,
        TIME_DETECTED,
        PRIORITY     ,
        STATUS       ,
        TYPE
FROM    V$HM_FINDING
WHERE   ROWNUM < 20
ORDER BY TIME_DETECTED DESC;

