-- NAME: MVRACPDnTap_adrproblemlist.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    Summersky Enterprises - www.summersky.biz
-- ------------------------------------------------------------------------
-- PURPOSE:
-- Script generates a summary of all the currently encountered problems 
-- on the various instances in the cluster.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported by Summersky Enterprises.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 18 - Problem Diagnostics
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR breaks
set pagesize 60 SPACE 2 numwidth 8 linesize 80 verify OFF
set pagesize 10000
COL adr_home format a28 heading "       ADR Home"
COL action_name format a10 heading "Action|Name"
COL problem_id format 9999 heading "P-id"
COL problem_key format a60
COL incident_cnt format 999 heading "Inc|Cnt"
SELECT problem_id,
       problem_key,
       incident_cnt
FROM   v$diag_vproblem
ORDER  BY adr_home,
          problem_id;   
