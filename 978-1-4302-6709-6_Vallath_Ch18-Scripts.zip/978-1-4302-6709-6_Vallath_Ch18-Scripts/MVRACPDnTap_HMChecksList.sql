-- NAME: MVRACPDnTap_HMChecklist.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    Summersky Enterprises - www.summersky.biz
-- ------------------------------------------------------------------------
-- PURPOSE:
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported by Summersky Enterprises.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 18 - Problem Diagnostics
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks;
col internal_check heading "Internal | Check"
col offline_capable heading "Offline |Capable"
SELECT name,
       cls_name,
       internal_check,
       offline_capable
FROM   v$hm_check;  

