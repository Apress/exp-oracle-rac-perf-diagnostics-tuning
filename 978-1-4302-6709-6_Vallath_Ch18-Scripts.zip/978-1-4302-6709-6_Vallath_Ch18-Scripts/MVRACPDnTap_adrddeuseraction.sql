-- NAME: MVRACPDnTap_adrddeuseraction.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    Summersky Enterprises - www.summersky.biz
-- ------------------------------------------------------------------------
-- PURPOSE:
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported by Summersky Enterprises.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 18 - Problem Diagnostics
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR breaks
set pagesize 60 SPACE 2 numwidth 8 linesize 110 verify OFF
set pagesize 10000
COL INT format 99 heading "In"
COL adr_home format a28 heading "       ADR Home"
COL action_name format a10 heading "Action|Name"
COL incident_id heading "Incident|   id"
COL invocation_id heading "invocation|    id"
SELECT adr_home,
       action_name,
       incident_id,
       invocation_id
FROM   v$diag_dde_user_action; 