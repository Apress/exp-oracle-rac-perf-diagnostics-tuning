-- NAME: MVRACPDnTap_SrvModSum.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    URL: muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
--  
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 15 - Optimizing Distributed Workload
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
set pages 200
CLEAR BREAKS
set pagesize 60 space 2 numwidth 8 linesize 140 verify off
SET ECHO OFF
COL SERVICE_NAME FORMAT A8 truncate
COL MACHINE FORMAT A20 truncate
COL MODULE FORMAT A12 TRUNCATE
COL STAT_NAME FORMAT A35
COL INT FORMAT 999
SELECT INST_ID INT,
       MODULE,
       STAT_NAME,
       SUM(VALUE)
FROM GV$SERV_MOD_ACT_STATS
GROUP BY INST_ID,MODULE,STAT_NAME;
