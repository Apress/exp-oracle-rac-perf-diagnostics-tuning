-- NAME: MVRACPDnTap_dbrm.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    URL: muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
--  
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 15 - Optimizing Distributed Workload
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
EXEC DBMS_RESOURCE_MANAGER.CREATE_PENDING_AREA();
EXECUTE 
DBMS_RESOURCE_MANAGER.CREATE_CONSUMER_GROUP 
                 (CONSUMER_GROUP=>‘HIGH_P’,
                  COMMENT=>’High Priority group’);

EXECUTE
 DBMS_RESOURCE_MANAGER.SET_CONSUMER_GROUP_MAPPING 
                   (ATTRIBUTE=>DBMS_RESOURCE_MANAGER.SERVICE_NAME, 
                    VALUE=> ‘TAPS’, 
                    CONSUMER_GROUP=>‘HIGH_P’);

SELECT ATTRIBUTE, 
       VALUE, 
 CONSUMER_GROUP 
FROM   DBA_RSRC_GROUP_MAPPINGS 
WHERE  ATTRIBUTE LIKE ‘%SERVICE%’;

EXEC DBMS_RESOURCE_MANAGER.SUBMIT_PENDING_AREA();

EXECUTE DBMS_SCHEDULER.CREATE_JOB_CLASS -
             (JOB_CLASS_NAME => ‘SSKY’, -
              RESOURCE_CONSUMER_GROUP => NULL, -
              SERVICE=> ‘SSKY’, -
              LOGGING_LEVEL=> DBMS_SCHEDULER.LOGGING_RUNS,-
              LOG_HISTORY => 30);


SELECT JOB_CLASS_NAME,
       SERVICE 
FROM DBA_SCHEDULER_JOB_CLASSES
WHERE SERVICE LIKE ‘%SRV%’;


EXEC DBMS_SCHEDULER.CREATE_JOB- 
(JOB_NAME=>'SSKY_REPORTING_JOB', -
JOB_TYPE=>'EXECUTABLE', -  
JOB_ACTION=>'/usr/apps/batch/SSKYnightlybatch;', -
JOB_CLASS=>'SSKY',-
ENABLED=>TRUE, -
AUTO_DROP=>FALSE, -
COMMENTS=>'Batch Reporting');

BEGIN
   DBMS_RESOURCE_MANAGER.CREATE_PLAN (high_p_plan, ' ');
   DBMS_RESOURCE_MANAGER.CREATE_PLAN_DIRECTIVE
        (PLAN                         => 'SSKY_PLAN1',
        GROUP_OR_SUBPLAN              => 'OTHER_GROUPS',
        COMMENT                       => ' ',
        CPU_P1                        => 0,
        CPU_P2                        => 0,
        CPU_P3                        => 0,
        CPU_P4                        => 0,
        CPU_P5                        => NULL,
        CPU_P6                        => NULL,
        CPU_P7                        => NULL,
        CPU_P8                        => NULL,
        PARALLEL_DEGREE_LIMIT_P1      => 40,
        ACTIVE_SESS_POOL_P1           => 100,
        QUEUEING_P1                   => 30,
        SWITCH_GROUP                  => 'LOW_GROUP',
        SWITCH_TIME                   => NULL,
        SWITCH_ESTIMATE               => TRUE,
        MAX_EST¬_EXEC_TIME             => 15,
        UNDO_POOL                     => NULL,
        MAX_IDLE_TIME                 => 40,
        MAX_IDLE_BLOCKER_TIME         => 5,
        SWITCH_TIME_IN_CALL           => 60
        );
   DBMS_RESOURCE_MANAGER.CREATE_PLAN_DIRECTIVE
       (PLAN                          => 'SSKY_PLAN1',
        GROUP_OR_SUBPLAN              => 'HIGH_P',
        COMMENT                       => ' ',
        CPU_P1                        => 60,
        CPU_P2                        => 20,
        CPU_P3                        => 10,
        CPU_P4                        => 5,
        CPU_P5                        => NULL,
        CPU_P6                        => NULL,
        CPU_P7                        => NULL,
        CPU_P8                        => NULL,
        PARALLEL_DEGREE_LIMIT_P1      => NULL,
        ACTIVE_SESS_POOL_P1           => 100,
        QUEUEING_P1                   => 30,
        SWITCH_GROUP                  => 'LOW_GROUP',
        SWITCH_TIME                   => NULL,
        SWITCH_ESTIMATE               => TRUE,
        MAX_EST_EXEC_TIME             => 15,
        UNDO_POOL                     => NULL,
        MAX_IDLE_TIME                 => 40,
        MAX_IDLE_BLOCKER_TIME         => 5,
        SWITCH_TIME_IN_CALL           => 60
       );
   DBMS_RESOURCE_MANAGER.CREATE_PLAN_DIRECTIVE
       (PLAN                          => 'SSKY_PLAN1',
        GROUP_OR_SUBPLAN              => 'LOW_P',
        COMMENT                       => ' ',
        CPU_P1                        => 20,
        CPU_P2                        => 5,
        CPU_P3                        => NULL,
        CPU_P4                        => NULL,
        CPU_P5                        => NULL,
        CPU_P6                        => NULL,
        CPU_P7                        => NULL,
        CPU_P8                        => NULL,
        PARALLEL_DEGREE_LIMIT_P1      => NULL,
        ACTIVE_SESS_POOL_P1           => 100,
        QUEUEING_P1                   => 30,
        SWITCH_GROUP                  => 'LOW_GROUP',
        SWITCH_TIME                   => NULL,
        SWITCH_ESTIMATE               => TRUE,
        MAX_EST_EXEC_TIME             => 15,
        UNDO_POOL                     => NULL,
        MAX_IDLE_TIME                 => 40,
        MAX_IDLE_BLOCKER_TIME         => 5,
        SWITCH_TIME_IN_CALL           => 60
       );
   DBMS_RESOURCE_MANAGER.SUBMIT_PENDING_AREA ();
   EXECUTE IMMEDIATE 'ALTER SYSTEM SET resource_manager_plan =''HIGH_P_PLAN'' SID=''SSKYDB_2''';
   EXECUTE IMMEDIATE 'ALTER SYSTEM SET resource_manager_plan =''HIGH_P_PLAN'' SID=''SSKYDB_3''';
END;


EXECUTE DBMS_SERVER_ALERT.SET_THRESHOLD -
(METRICS_ID => DBMS_SERVER_ALERT.ELAPSED_TIME_PER_CALL, -
 WARNING_OPERATOR => DBMS_SERVER_ALERT.OPERATOR_GE, -
 WARNING_VALUE => '500',-
 CRITICAL_OPERATOR => DBMS_SERVER_ALERT.OPERATOR_GE,- 
 CRITICAL_VALUE => '7500', -
 OBSERVATION_PERIOD => 1,-
 CONSECUTIVE_OCCURRENCES => 5,- 
 INSTANCE_NAME => NULL,-
 OBJECT_TYPE => DBMS_SERVER_ALERT.OBJECT_TYPE_SERVICE,- 
 OBJECT_NAME => 'RAPTEST'); 

EXECUTE DBMS_MONITOR.SERV_MOD_ACT_STAT_ENABLE -
        (SERVICE_NAME=> ‘TAPS’, - 
         MODULE_NAME => ‘CRM’, -
         ACTION_NAME => ‘EXCEPTION’);

