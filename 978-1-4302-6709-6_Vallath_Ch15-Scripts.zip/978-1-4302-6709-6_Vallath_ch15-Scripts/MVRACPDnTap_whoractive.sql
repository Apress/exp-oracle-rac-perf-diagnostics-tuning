-- NAME: MVRACPDnTap_whoractive.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    URL: muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
--  
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 15 - Optimizing Distributed Workload
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set feedback off heading off linesize 132 trimspool on 
select '                         ************* All Session(s) ' ||
	to_char(sysdate,'mm/dd/rr hh24:mi') ||
			       ' *************' from dual;
col username format a10    trunc heading "User Name"
col inst_id format 99      trunc heading "Ins|ID"
col logon_time format a11  trunc heading "Logon Time"
col machine format a12     trunc heading "Machine"
col "Action" format a18    trunc heading "Action"
col SID_SER format a12     trunc heading "SesID,Ser#" 
col status    format a1    trunc heading "S|t|a|t|u|s"
col lockwait  format a1    trunc heading "L|o|c|k|w|a|i|t"
col sql_id format a13      trunc heading "Sql ID" 
col SERVICE_NAME format a8 trunc heading "Service" 
column action_program format a26 trunc
column SID_SER format a12 heading "SesID,Ser#" 
column module format a20 truncate
column spid format a7 

set linesize 200 trimspool ON
set pagesize 100
set heading ON
set feedback ON verify OFF echo OFF
SELECT S.inst_id,
       s.username                              "Username",
       ' '
       ||To_char(s.sid)
       ||','
       || To_char(s.serial#)                   "SID_SER",
       s.service_name,
       To_char(s.logon_time, 'mm/dd hh24:mi ') logon_time,
       Substr(s.status, 1, 1)                  status,
       Decode(action, NULL, NULL,
                      action
                      ||' ')
       ||Substr(s.program, 1, 40)              action_program,
       s.machine                               Machine,
       s.MODULE
FROM   gv$session s
WHERE  username IS NOT NULL
       AND status = 'ACTIVE'
ORDER  BY logon_time,
          inst_id;  
          