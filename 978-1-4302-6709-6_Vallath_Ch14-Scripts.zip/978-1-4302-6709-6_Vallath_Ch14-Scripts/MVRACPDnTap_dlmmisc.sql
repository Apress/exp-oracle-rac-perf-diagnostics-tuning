-- NAME: MVRACDPnTap_dlmmisc.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script gives you the distributed lock manager activity across the 
-- network specifically around the message traffic
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 14 - Tuning the Cluster Interconnect
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR BREAKS
set pagesize 60 space 2 numwidth 10 linesize 132 verify off
COL INST_ID FORMAT 9999999999
SELECT * FROM (SELECT INST_ID,NAME,VALUE FROM GV$DLM_MISC) PIVOT (SUM(value) for  INST_ID IN (1,2,3,4,5,6,7,8)) ORDER BY NAME;
