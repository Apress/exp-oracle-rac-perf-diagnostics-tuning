-- NAME: MVRACPDnTap_blksndtime.SQL
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 14 - Tuning the Cluster Interconnect
—-    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set pagesize 60 space 2 numwidth 8 linesize 100 verify off
SET ECHO OFF
set time on;
COL "gc cr BR" print
COL "gc cr BRT" print
COL "gc cur BR" print
COL "gc cur BRT" print
COL "Avg CR BRT(ms)" FORMAT 99999.99 heading "Avg CR | BRT (ms)"
COL "Avg CUR BRT(ms)" FORMAT 9999.99 heading "Avg CUR | BRT (ms)"
COL INT FORMAT 999
SELECT
    B1.INST_ID INT,
    B2.VALUE "gc cr BR",
    B1.VALUE "gc cr BRT",
    B4.VALUE "gc cur BR",
    b3.value "gc cur BRT",
    ((B1.VALUE/B2.VALUE ) *10) "Avg CR BRT(ms)",
    ((B3.VALUE/B4.VALUE ) *10) "Avg CUR BRT(ms)"
FROM GV$SYSSTAT B1,
     GV$SYSSTAT B2,
     GV$SYSSTAT B3,
     GV$SYSSTAT B4
WHERE B1.NAME = 'gc cr block receive time'
AND   B2.NAME = 'gc cr blocks received' 
AND   B3.NAME = 'gc current block receive time'
AND   B4.NAME = 'gc current blocks received' 
AND   B1.INST_ID = B2.INST_ID
AND   B1.INST_ID = B3.INST_ID
AND   B1.INST_ID = B4.INST_ID
ORDER BY 1
/
COL "Avg CR Block Receive Time(ms)" FORMAT 999999999.9 heading "Avg CR Block | Receive Time(ms)"
SELECT
    B1.INST_ID,
    B2.VALUE "GCS Blocks Received",
    B1.VALUE "GCS Blocks Receive Time",
    ((B1.VALUE/B2.VALUE ) *10) "Avg CR Block Receive Time(ms)"
FROM GV$SYSSTAT B1,
     GV$SYSSTAT B2
WHERE B1.NAME = 'gc cr block receive time'
AND   B2.NAME = 'gc cr blocks received'
AND   B1.INST_ID = B2.INST_ID
ORDER BY 1
/

