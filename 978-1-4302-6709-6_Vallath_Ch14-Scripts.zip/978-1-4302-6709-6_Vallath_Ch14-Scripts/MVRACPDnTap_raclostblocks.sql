-- NAME: MVRACPDnTap_raclostblocks.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    Summersky Enterprises - www.summersky.biz
-- ------------------------------------------------------------------------
-- PURPOSE:
-- Blocks can be corrupted or lost during transfer across the interconnect. 
-- This script helps determine the number of blocks lost /corrupted over 
-- the interconnect since the instance was started.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported by Summersky Enterprises.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 14 - Tuning the Cluster Interconnect
—-    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set pagesize 60 SPACE 2 numwidth 8 linesize 132 verify OFF
col inst_id format 99 trunc heading "Ins|ID"
COL instance_name format a10 heading " Instance | Name"
COL host_name format a24 heading " Host Name"
COL blkl heading " Blocks |Lost "
COL "Days" format 999 heading "Uptime|(Days)"
COL "Hours" format 99999 heading "Uptime|(Hours)"
COL "Perhr" format 999999 heading "Blks Lost| Per Hour"
COL blkc heading " Blocks |Corrupt"
COL startup_time heading "Instance | Startup Time"
SELECT A1.inst_id,
       A3.instance_name,
       A3.host_name,
       A3.startup_time,
       Round (SYSDATE - startup_time)                        "Days",
       Round (( SYSDATE - startup_time ) * 24)               "Hours",
       A1.value                                              "BLKL",
       A1.value / ( Round(( SYSDATE - startup_time ) * 24) ) "Perhr",
       A2.value                                              "BLKC"
FROM   gv$sysstat A1,
       gv$sysstat A2,
       gv$instance A3
WHERE  A1.name = 'gc blocks lost'
       AND A2.name = 'gc blocks corrupt'
       AND A1.inst_id = A2.inst_id
       AND A1.inst_id = A3.instance_number
ORDER  BY 1;
