-- NAME: MVRACPDnTap_Dynamicremasterstats.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    Summersky Enterprises - www.summersky.biz
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The data from the query provides an indication of the overall activity 
-- of remaster operations and the time spent at various stages of the operation
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported by Summersky Enterprises.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 14 - Tuning the Cluster Interconnect
—-    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
SET ECHO OFF
COL INST_ID FORMAT 999 heading "Inst"
COL REMASTER_OPS heading "Remaster|Operations"
COL REMASTERED_OBJECTS heading "Remaster|Objects"
COL REMASTER_TIME heading "Remaster|Time"
COL QUIESCE_TIME heading "Quiesce|Time"
COL FREEZE_TIME heading "Freeze|Time"
COL CLEANUP_TIME heading "Cleanup|Time"

SELECT inst_id,
       remaster_ops,
       remaster_time,
       remastered_objects,
       quiesce_time,
       freeze_time,
       cleanup_time
FROM   gv$dynamic_remaster_stats
ORDER  BY inst_id;  