-- NAME: MVRACPDnTap_dlmtrafficntrl.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- When a message needs to be sent the process needs to acquire a ticket 
-- from the pool and return the ticket back to the pool once the message 
-- has been transmitted.   When there is a message flooding, there may not 
-- be sufficient amount of tickets in the pool and the process requesting 
-- for the ticket will have to wait for the ticket.  The script displays the
-- current usage of tickets. 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 14 - Tuning the Cluster Interconnect
—-    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR BREAKS
set pagesize 60 space 2 numwidth 10 linesize 140 verify off
COL INT FORMAT 99 heading "In"
COL LNID FORMAT 99
COL RNID FORMAT 99
COL RRID FORMAT 99
COL RINC FORMAT 999
COL TCKT_AVAIL FORMAT 9999 heading "Tckt|Avail"
COL TCKT_LIMIT FORMAT 9999 heading "Tckt|Limit"
COL TCKT_RCVD FORMAT 9999 heading "Tckt|Rcvd"
COL TCKT_WAIT FORMAT A4 trunc heading "Wait"
COL SND_Q_MAX heading "Send Q|Max"
COL SND_Q_TOT heading "Send Q|Total"
COL SND_Q_LEN noprint
COL SND_Q_TM_WRAP NOPRINT
COL SND_SEQ_NO NOPRINT
COL SND_Q_TM_BASE NOPRINT
BREAK ON INT SKIP 1
SELECT inst_id    INT,
       local_nid  LNID,
       remote_nid RNID,
       remote_rid RRID,
       remote_inc RINC,
       tckt_avail,
       tckt_limit,
       tckt_rcvd,
       tckt_wait,
       snd_seq_no,
       snd_q_len,
       snd_q_max,
       snd_q_tot,
       snd_q_tm_base,
       snd_q_tm_wrap
FROM   gv$dlm_traffic_controller
ORDER  BY inst_id,
          tckt_avail;

