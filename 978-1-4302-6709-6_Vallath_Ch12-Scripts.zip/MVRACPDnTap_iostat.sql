-- NAME: MVRACPDnTap_iostat.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script displays information regarding disk I/O statistics of database files.   
-- Statistics for data files and temp files are listed for each file, however for other 
-- types of files such as archive logs and backupsets statistics is consolidated into 
-- one entry
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 12 - Tuning the Storage Subsystem
—-    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--

CLEAR BREAKS
set pagesize 60 space 2 numwidth 8 linesize 138 verify off
COL LARGE_READ_MEGABYTES heading "Large Read| (Megabytes)"
COL SMALL_READ_MEGABYTES heading "Small Read| Megabytes)"
COL LARGE_READ_REQS heading "Large Read|Reqs"
COL SMALL_READ_REQS heading "Small Read|Reqs"
COL ASYNCH_IO heading "Asynch.| IO"
COL LARGE_READ_SERVICETIME heading "Large Read | Service Time"
COL RETRIES_ON_ERROR heading "Retries on |Error"
COL FILE_NO FORMAT 9999 heading "File|  #"
COL FILETYPE_NAME FORMAT A20 TRUNC heading "File Type"

SELECT file_no,
       filetype_name,
       small_read_megabytes,
       large_read_megabytes,
       large_read_servicetime
FROM   v$iostat_file