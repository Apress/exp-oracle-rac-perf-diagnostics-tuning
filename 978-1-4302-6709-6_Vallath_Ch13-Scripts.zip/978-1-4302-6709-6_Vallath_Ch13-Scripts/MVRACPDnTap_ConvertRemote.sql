-- NAME: MVRACPDnTap_convertremote.SQL
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script displays average convert times, count information, and timed statistics 
-- for global enqueue requests for CURRENT blocks. The script helps to determine the 
-- type of locks conversions that did not occur locally on the instance and had happened 
-- on one of the remote instances in the cluster
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning the global cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR BREAKS
set pagesize 60 space 2 numwidth 8 linesize 138 verify off
set pagesize 10000
COL INT FORMAT 999 heading "Cur|Inst"
COL CT heading "Convert Type"
COL ACT heading "Average|Convert Time"
COL CC heading "Convert Count"
break on int skip 1
SELECT inst_id              INT,
       convert_type         CT,
       average_convert_time ACT,
       convert_count        CC
FROM   gv$ges_convert_remote
WHERE  average_convert_time > 0
ORDER  BY inst_id;
