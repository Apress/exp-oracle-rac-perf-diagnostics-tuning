-- NAME: MVRACTnTop_reslimit.SQL
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The query lists the current utilization of the global cache section of the 
-- instance memory.  When the current utilization equals or nears the value of the
-- initial allocation, its an indication to resize the appropriate memory parameters
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning Global Cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set linesize132
set pagesize 100
set heading on
COL RESOURCE_NAME FORMAT A20
COL INT FORMAT 999
COL LV FORMAT A10
COL IA FORMAT A10
BREAK ON INT SKIP 1
SELECT
      INST_ID INT,
      RESOURCE_NAME,
      CURRENT_UTILIZATION CU,
      MAX_UTILIZATION MU,
      INITIAL_ALLOCATION IA,
      LIMIT_VALUE LV
FROM  GV$RESOURCE_LIMIT
WHERE MAX_UTILIZATION > 0 AND
      RESOURCE_NAME LIKE 'g%'
ORDER BY INST_ID, RESOURCE_NAME 
/
