-- NAME: MVRACPDnTap_latch_childrenbc.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script lists the latch addresses that have the highest sleep before acquiring 
-- the next latch.  
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning the global cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks 
set pagesize 160 linesize 100 space 2 numwidth 8 verify off 
SET echo off 
col INT format 999 
break ON INT skip 1 
SELECT inst_id INT, 
       child#  "Child", 
       addr    "Address", 
       gets    "Gets", 
       misses  "Misses", 
       sleeps  "Sleeps" 
FROM   gv$latch_children 
WHERE  NAME = 'cache buffers chains' 
       AND sleeps > 100 
ORDER  BY 1, 
          6, 
          2, 
          3;

