-- NAME: MVRACPDnTap_crblksrvr.SQL
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script list the CR blocks servered statistics 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning the global cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR BREAKS
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
COL INT FORMAT 99 heading "In"
COL "BR" Heading    "Blocks|Received"
col "HBLMS" Heading "Reqsts|Handled|By LMS"
col "DR" heading    "Disk|Reads"
col "FR" heading    "Failures"
COL FLUSHES heading "Flushes"
COL "FDC" heading "Down|Converts"
COL "FMT" FORMAT 9999999  heading   "Flush|Time"
COL "LT" heading    "Light|Works"
COL "FQ" heading  "Flushes|Queued"
COL "ERR" heading   "Errors"
SELECT  INST_ID INT,
      (CR_REQUESTS+CURRENT_REQUESTS) "BR",   
      (DATA_REQUESTS+UNDO_REQUESTS+TX_REQUESTS) "HBLMS",
      DISK_READ_RESULTS "DR",
      FAIL_RESULTS "FR",
      FAIRNESS_DOWN_CONVERTS "FDC",
      FLUSHES,
      FLUSH_MAX_TIME "FMT",
      LIGHT_WORKS  "LW",
      ERRORS "ERR"
FROM  GV$CR_BLOCK_SERVER 
ORDER BY INST_ID;

