-- NAME: MVRACPDnTap_blockers.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script helps to identify lockers and the sessions that are blocked from due
-- to chained waits.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning the global cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--

clear breaks
set pagesize 60 SPACE 2 numwidth 8 linesize 200 verify OFF
SET echo OFF
col username format a10 trunc heading "User Name"
col inst_id format 99 trunc heading "Ins|ID"
col logon_time format a11 trunc heading "Logon Time"
col machine format a12 trunc heading "Machine"
col "Action" format a18 trunc heading "Action"
col sid_ser format a12 trunc heading "SesID,Ser#"
col status format a1 trunc heading "S|t|a|t|u|s"
col event format a20 trunc heading "Wait | Event"
col osuser format a10 trunc heading "O/S |User"
col process format a8 trunc heading "Process"
col MODULE format a16 trunc heading "Module"
col SCHEMA format a12 trunc heading "Schema"
col lockwait format a1 trunc heading "L|o|c|k|w|a|i|t"
col state format a12 trunc heading "Session|State"
col sql_id format a13 trunc heading "Sql ID"
col service_name format a8 trunc heading "Service"
col blocking_session format 99999 trunc heading "Blocker"
SELECT s.inst_id,
       s.username,
       ' '
       ||To_char(s.sid)
       ||','
       || To_char(s.serial#)                   "SID_SER",
       To_char(s.logon_time, 'mm/dd hh24:mi ') logon_time,
       Substr(s.status, 1, 1)                  status,
       s.lockwait,
       s.service_name,
       s.process,
       s.sql_id,
       s.blocking_session,
       s.event,
       s.seconds_in_wait                       siw,
       s.osuser,
       s.MODULE,
       s.machine,
       Decode(lmode, 0, 'None',
                     1, 'Null',
                     2, 'Row-S',
                     3, 'Row-X',
                     4, 'Share',
                     5, 'S/ROW',
                     6, 'Exclusive')           LMODE,
       Decode(request, 0, 'None',
                       1, 'Null',
                       2, 'Row-S',
                       3, 'Row-X',
                       4, 'Share',
                       5, 'S/ROW',
                       6, 'Exclusive')         REQUEST,
       Decode(request, 0, 'BLOCKER',
                       'WAITER')               STATE,
       S.seconds_in_wait                       SIW
FROM   gv$global_blocked_locks G,
       gv$session S
WHERE  G.sid = S.sid
       AND G.inst_id = S.inst_id
ORDER  BY state;  