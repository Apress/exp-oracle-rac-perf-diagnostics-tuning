-- NAME: MVRACPDnTap_seglatchstats.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The query helps determine the objects and the number of times that the object has 
-- been touched.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning the global cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks 
set pagesize 160 linesize 100 space 2 numwidth 8 verify off 
SET echo off 
col INT format 999 
break ON INT skip 1 
SELECT e.owner 
                   ||'.' 
                   || e.segment_name         segment_name, 
                   e.extent_id               extent#, 
                   x.dbablk - e.block_id + 1 block#, 
                   x.tch, 
                   l.child# 
FROM   sys.v$latch_children l, 
       sys.x$bh x, 
       sys.dba_extents e 
WHERE  x.hladdr = '0000001123570C50' 
       AND e.file_id = x.file# 
       AND x.hladdr = l.addr 
       AND x.dbablk BETWEEN e.block_id AND e.block_id + e.blocks - 1 
ORDER  BY x.tch DESC;  