- NAME: MVRACPDnTap_objpolicystats.SQL
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script against the X$OBJECT_POLICY_STATISTICS gives current 
-- statistics on type of access the objects have on the instances they 
-- are currently being mastered. SOPENS column indicates the number of times 
-- the object has been master on the instance in shared mode. XOPENS indicate 
-- exclusive mode and XREFS indicates exclusive reference.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning global cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR BREAKS

CLEAR BREAKS
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
set pagesize 10000
COL INT FORMAT 999  noprint
COL OBJID FORMAT 99999999
COL ONAME FORMAT A29 print
COL SONAME FORMAT A28 print
COL OT FORMAT A4
break on int skip 1
SELECT object                            OBJID,
       object_name                       ONAME,
       subobject_name                    SONAME,
       Decode(object_type, 'TABLE PARTITION', 'TP',
                           'TABLE SUBPARTITION', 'TSP',
                           'TABLE', 'T',
                           'INDEX SUBPARTITION', 'ISP',
                           'INDEX PARTITION', 'IP',
                           'CLUSTER', 'C',
                           'SEQUENCE', 'S',
                           'INDEX', 'I') OT,
       node,
       sopens,
       xopens,
       xfers,
       dirty
FROM   x$object_policy_statistics,
       dba_objects DO
WHERE  object = DO.data_object_id;



