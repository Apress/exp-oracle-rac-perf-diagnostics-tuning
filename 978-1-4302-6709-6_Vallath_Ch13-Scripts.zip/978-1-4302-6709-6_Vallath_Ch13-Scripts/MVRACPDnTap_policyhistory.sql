-- NAME: MVRACPDnTap_policyhistory.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, 
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script helps to understand what type of policy was used while the objects where 
-- remastered from one instance to the other.  The query looks at historical behavior by
-- querying the V$POLICY_HISTORY view.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning the global cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
SET ECHO OFF
COL POLICY_EVENT FORMAT A20  heading "Policy Event"
COL TARGET_INSTANCE_NUMBER FORMAT 999 heading "Target | Inst #"
COL EVENT_DATE FORMAT A20 heading "Event | Date"
COL DATA_OBJECT_ID heading "Data | Object ID"
COL INST_ID FORMAT 999 heading "Inst"
SELECT inst_id,
       policy_event,
       data_object_id,
       target_instance_number,
       event_date
FROM   gv$policy_history
WHERE  data_object_id IN (SELECT data_object_id
                          FROM   gv$policy_history
                          GROUP  BY data_object_id
                          HAVING Count(*) > 19)
ORDER  BY data_object_id,
          inst_id; 