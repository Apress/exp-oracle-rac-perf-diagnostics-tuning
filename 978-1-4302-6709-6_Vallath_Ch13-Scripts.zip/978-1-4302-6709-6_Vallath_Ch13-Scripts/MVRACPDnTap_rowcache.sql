-- NAME: MVRACPDnTap_rowcache.SQL
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- This script displays statistics showing the cache behavior of the dictionary cache. 
-- The dictionary cache is part of the shared pool and does not have any tunable 
-- parameters other than the SHARED_POOL initialization parameter itself. This means 
-- that if the shared pool has not been sized correctly there is a direct impact on the 
-- dictionary cache.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning the global cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set pagesize 160 linesize 100 space 2 numwidth 8 verify off
SET ECHO OFF
col int format 999
column parameter format a26
column pct_succ_gets format 99999.9
column updates format 9999,999,999
col gets format 9999999999
break on int skip 1

SELECT inst_id                                 INT,
       parameter,
       SUM(gets)                               gets,
       SUM(getmisses)                          misses,
       100 * SUM(gets - getmisses) / SUM(gets) pct_succ_gets,
       SUM(modifications)                      updates
FROM   gv$rowcache
WHERE  gets > 0
GROUP  BY inst_id,
          parameter
ORDER  BY inst_id;  
