-- NAME: MVRACPDnTap_blkpreptime.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The query will help determine the average time spent to prepare the block 
-- for the requestor.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning global cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR BREAKS
clear breaks
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
SET ECHO OFF
set time on;
COL INT FORMAT 999
COL CRBT FORMAT 999999 noprint
COL CRFT FORMAT 999999 noprint
COL CURFT FORMAT 999999 noprint
COL CRST FORMAT 999999 noprint
COL CURST FORMAT 999999 noprint
COL CURPT FORMAT 999999999 noprint
COL "PREP TIME" FORMAT 9999.99 print
COL "BLK SRV TIME" FORMAT 99999999999 print
COL "CR SRV" FORMAT 99999999 noprint
COL "CUR SRV" FORMAT 999999999 noprint
SELECT b1.INST_ID INT, 
       b1.VALUE "CRBT",
       b2.VALUE "CRFT",
       b3.value "CURFT",
       b4.value "CRST",
       b5.value "CURST",
       b6.value "CURPT",
       b7.VALUE "CR SRV",
       b8.VALUE "CUR SRV",
   ((b1.VALUE + b2.VALUE + b3.VALUE + b4.value + b5.value + b6.value)*10) "BLK SRV TIME",
   (b7.VALUE + b8.VALUE) "BLK SRVD",
   ((b7.VALUE + b8.VALUE)/((b1.VALUE + b2.VALUE + b3.VALUE + b4.value + b5.value + b6.value)*10)) "PREP TIME"
FROM GV$SYSSTAT b1, 
     GV$SYSSTAT b2,
     GV$SYSSTAT b3,
     GV$SYSSTAT b4,
     GV$SYSSTAT b5,
     GV$SYSSTAT b6,
     GV$SYSSTAT b7,
     GV$SYSSTAT b8
WHERE b1.NAME = 'gc cr block build time' 
AND   b2.NAME = 'gc cr block flush time' 
AND   b3.NAME = 'gc current block flush time' 
AND   b4.NAME = 'gc cr block send time' 
AND   b5.NAME = 'gc current block send time' 
AND   b6.NAME = 'gc current block pin time'
AND   b7.NAME = 'gc cr blocks served' 
AND   b8.NAME = 'gc current blocks served'  
AND   b1.INST_ID = b2.INST_ID
AND   b1.INST_ID = b3.INST_ID
AND   b1.INST_ID = b4.INST_ID
AND   b1.INST_ID = b5.INST_ID
AND   b1.INST_ID = b6.INST_ID
AND   b1.INST_ID = b7.INST_ID
AND   b1.INST_ID = b8.INST_ID
ORDER BY 1;

