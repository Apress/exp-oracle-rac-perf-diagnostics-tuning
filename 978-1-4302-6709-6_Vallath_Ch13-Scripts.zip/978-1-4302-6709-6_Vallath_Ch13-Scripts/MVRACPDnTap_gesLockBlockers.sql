-- NAME: MVRACPDnTap_gesLockBlockers.SQL
-- ------------------------------------------------------------------------
-- Source:  Oracle Documentation
--    
-- ------------------------------------------------------------------------
-- PURPOSE:
-- This script shows GES Locks and blockers with grants and acquires  
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning global cache

--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)

--    by Murali Vallath

--    Publisher: APress, 2014

--
clear breaks
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
SET ECHO OFF
COL INT FORMAT 999
COL USERNAME FORMAT A14
COL SID_SER format a12 heading "SesID,Ser#"
COL SPID FORMAT A6 tru
COL RNAME FORMAT A24 tru
COL LOCK_STATE FORMAT A10 tru
COL REQ_LVL FORMAT A10 tru
COL GRANT_LVL FORMAT A10 tru
COL EVENT FORMAT A30 tru
BREAK on INT skip 1
SELECT dl.inst_id INT, 
       ' '||to_char(s.SID)||','|| to_char(s.serial#) "SID_SER",
       p.spid SPID, 
       dl.resource_name1 RNAME,
       decode (substr (dl.grant_level,1,8),'KJUSERNL','Null','KJUSERCR','Row-S (SS)','KJUSERCW','Row-X (SX)','KJUSERPR','Share','KJUSERPW','S/Row-X (SSX)','KJUSEREX','Exclusive',request_level) AS GRANT_LVL,
       decode (substr(dl.request_level,1,8),'KJUSERNL','Null','KJUSERCR','Row-S (SS)','KJUSERCW','Row-X (SX)','KJUSERPR','Share','KJUSERPW','S/Row-X (SSX)','KJUSEREX','Exclusive',request_level) AS REQ_LVL,
       decode (substr(dl.state,1,8),'KJUSERGR','Granted','KJUSEROP','Opening','KJUSERCA','Cancelling','KJUSERCV','Converting') AS LOCK_STATE,
       sw.event EVENT, sw.seconds_in_wait WTs
FROM gv$ges_enqueue dl, gv$process p, gv$session s, gv$session_wait sw
WHERE blocker=1 
AND (dl.inst_id = p.inst_id and dl.pid = p.spid)
AND (p.inst_id = s.inst_id and p.addr= s.paddr)
AND (s.inst_id = sw.inst_id and s.sid=sw.sid)
ORDER BY sw.seconds_in_wait  DESC;
