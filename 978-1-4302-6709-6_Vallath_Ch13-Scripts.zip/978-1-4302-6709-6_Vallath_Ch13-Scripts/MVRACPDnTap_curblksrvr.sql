-- NAME: MVRACPDnTap_curblksrvr.SQL
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script lists the current block servered statsistics
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning the global cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set pagesize 60 space 2 numwidth 8 linesize 120 verify off
COL INT FORMAT 99 heading "In"
COL pin100     format 9999999 heading "Pin|10-100|ms"
COL pin1000    format 9999999 heading "Pin|100-1000|ms"
COL pin10000   format 9999999 heading "Pin|1000-10000|ms"
COL flush100   format 9999999 heading "Flush|10-100|ms"
COL flush1000  format 9999999 heading "Flush|100-1000|ms"
COL write100   format 9999999 heading "Write|10-100|ms"
COL write1000  format 9999999 heading "Write|100-1000|ms"
COL write10000 format 9999999 heading "Write|1000-10000|ms"

SELECT inst_id INT,
       pin100,
       pin1000,
       pin10000,
       flush100,
       flush1000,
       write100,
       write1000,
       write10000,
       evictdc,
       writedc
FROM   gv$current_block_server
ORDER  BY inst_id;  

