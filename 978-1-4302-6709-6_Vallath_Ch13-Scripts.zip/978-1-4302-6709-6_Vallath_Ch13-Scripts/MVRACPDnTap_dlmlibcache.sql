-- NAME: MVRACPDnTap_dlmlibcache.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script displays statistics showing library cache performance and activities.  
-- When looking at RAC from each individual instance in the cluster, the RELOADS and 
-- INVALIDATIONS columns should be monitored.  RELOADS indicates the number of times 
-- the objects had to be reloaded into the library cache.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning the global cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR BREAKS
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
set pagesize 10000
COL INT FORMAT 999 heading "Inst"
COL NAMESPACE FORMAT A20
COL DLREQ heading "Lock|Requests"
COL DPREQ heading "Pin|Requests"
COL DPREL heading "Pin|Releases"
COL DINVREQ heading "Inval|Requests"
COL DINV heading "Invals"
break on int skip 1
SELECT inst_id                   INT,
       namespace,
       dlm_lock_requests         DLREQ,
       dlm_pin_requests          DPREQ,
       dlm_pin_releases          DPREL,
       dlm_invalidation_requests DINVREQ,
       dlm_invalidations         DINV
FROM   gv$librarycache
ORDER  BY inst_id;

