-- NAME: MVRACPDnTap_instCacheTrans.SQL
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The query displays statistics for blocks transferred among instances in the cluster,
-- the view captures data based on where the data is originated.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning the global cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR BREAKS
set pagesize 60 space 2 numwidth 8 linesize 150 verify off
set pagesize 10000
COL INT FORMAT 99 heading "In"
COL TRG_INST FORMAT 999 heading "Trg|Int"
COL CUR_BLK_TIM FORMAT  999999.99 heading "Current|Blk Time"
COL CR_BLK_TIM FORMAT 999999.99 heading "CR|Blk Time"
COL CUR_2HOP_TIM FORMAT 99999999.99 heading "Current|2HOP Time"
COL CUR_3HOP_TIM FORMAT 999999999.99 heading "Current|3HOP Time"
COL CUR_BUSY_TIM FORMAT 999999999.99 heading "Current|Busy Time"
COL CUR_CONG_TIM FORMAT 999999.99 heading "Current|Cong Time"
COL CUR_2HOP FORMAT 99999 Heading "2 Hop"
COL CUR_3HOP FORMAT 999999 Heading "3 Hop"
COL CUR_BUSY FORMAT 999999 Heading "Busy"
COL CUR_CONG FORMAT 999999 Heading "Cong"
COL CR_CONGESTED FORMAT 999999 Heading "Cong"
COL CLASS FORMAT A16 trunc
prompt ***************** Consistent Read (CR) Blocks

break on int skip 1
SELECT  INST_ID INT  ,
        INSTANCE TRG_INST,
        CLASS        ,
        CR_BLOCK     ,
        CR_BLOCK_TIME/1000 CR_BLK_TIM,
        CR_2HOP      ,
        CR_3HOP      ,
        CR_BUSY      ,
        CR_CONGESTED
FROM    GV$INSTANCE_CACHE_TRANSFER
WHERE   INSTANCE     < 9
        AND CR_BLOCK > 0
ORDER BY INST_ID,
        INSTANCE;
prompt ***************** Current Blocks 

SELECT  INST_ID INT       ,
        INSTANCE     TRG_INST     ,
        CLASS,
        CURRENT_BLOCK          CUR_BLK,
        CURRENT_BLOCK_TIME/1000     CUR_BLK_TIM,
        CURRENT_2HOP           CUR_2HOP,
        CURRENT_2HOP_TIME/1000      CUR_2HOP_TIM,
        CURRENT_3HOP           CUR_3HOP,
        CURRENT_3HOP_TIME/1000      CUR_3HOP_TIM,
        CURRENT_BUSY           CUR_BUSY,
        CURRENT_BUSY_TIME/1000      CUR_BUSY_TIM,
        CURRENT_CONGESTED      CUR_CONG,
        CURRENT_CONGESTED_TIME/1000 CUR_CONG_TIM
FROM    GV$INSTANCE_CACHE_TRANSFER
WHERE   INSTANCE < 9
        AND CURRENT_BLOCK > 0
ORDER BY INST_ID,
        INSTANCE;


