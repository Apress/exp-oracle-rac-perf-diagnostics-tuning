-- NAME: MVRACPDnTap_findhotobjmasters.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script lists the current (CM) and previous master (PM) instances for few of 
-- the objects. The output has been sorted on the objects that have been remastered the
-- highest (CNT column) since the instances were started.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning the global cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR BREAKS
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
set pagesize 1000
COL INT FORMAT 999
COL CM FORMAT A3
COL PM FORMAT A3
COL CNT FORMAT 999
COL OBJID FORMAT 99999999
COL ONAME FORMAT A29
COL SONAME FORMAT A28
COL OWNER FORMAT A6
COL OT FORMAT A4
break on INT skip 1
SELECT inst_id                                INT,
       owner,
       GCSPF.data_object_id                   OBJID,
       object_name                            ONAME,
       subobject_name                         SONAME,
       Decode(object_type, 'TABLE PARTITION', 'TP',
                           'TABLE SUBPARTITION', 'TSP',
                           'TABLE', 'T',
                           'INDEX SUBPARTITION', 'ISP',
                           'INDEX PARTITION', 'IP',
                           'CLUSTER', 'C',
                           'SEQUENCE', 'S',
                           'INDEX', 'I')      OT,
       gc_mastering_policy                    GC_MP,
       decode(CURRENT_MASTER,'0','1','1','2','2','3','3','4','4','5','5','6','6','7','7','8','8','9','9','10') CM, 
       decode(PREVIOUS_MASTER,'0','1','1','2','2','3','3','4','4','5','5','6','6','7','7','8','8','9','9','10','32767','NO') PM,
       remaster_cnt                           CNT
FROM   gv$gcspfmaster_info GCSPF,
       dba_objects DO
WHERE  GCSPF.data_object_id = DO.data_object_id
       AND remaster_cnt > 1
ORDER  BY inst_id,
          10 DESC;