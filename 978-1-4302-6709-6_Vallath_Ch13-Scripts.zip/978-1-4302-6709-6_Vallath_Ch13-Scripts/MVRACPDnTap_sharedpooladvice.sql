-- NAME: MVRACPDnTap_sharedpooladvice.SQL
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The scripts checks agains the shared_pool_adivice view and indicates  the current 
-- utilization of shared pool.  Based on the frequent need for higher shared pool, 
-- increasing the start value to 30G provided improved performances
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 13 - Tuning the global cache
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set linesize132
set pagesize 100
set heading on
COL INT FORMAT 999
COL "EST. HITS" FORMAT 999999999999999999
BREAK ON INT SKIP 1

column shared_pool_size_factor format 999.90 heading 'SP SIZE FCTR'
SELECT inst_id INT, SHARED_POOL_SIZE_FOR_ESTIMATE "SP SIZE ESTD",
       SHARED_POOL_SIZE_FACTOR,
       ESTD_LC_SIZE "ESTD LC SIZE",
       ESTD_LC_MEMORY_OBJECTS "ESTD MEM OBJ",
       ESTD_LC_TIME_SAVED  "ESTD TM SAVED",
       ESTD_LC_MEMORY_OBJECT_HITS  "EST. HITS"
FROM GV$SHARED_POOL_ADVICE
/

