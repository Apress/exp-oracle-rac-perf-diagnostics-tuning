-- NAME: MVRACPDnTap_lockmodes.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    blog - www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 17 - Waits Enqueues and Latches
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--

clear breaks
SELECT inst_id,
       sid,
       type,
       id1,
       id2,
       lmode,
       request,
       ctime,
       block
FROM   gv$lock;  