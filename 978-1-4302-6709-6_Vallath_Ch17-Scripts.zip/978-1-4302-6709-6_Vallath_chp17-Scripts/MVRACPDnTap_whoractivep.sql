
-- NAME: MVRACPDnTap_whoractivep.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    blog - www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:  the script will list the current row cache information 
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 17 - Waits Enqueues and Latches
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set feedback off heading off linesize 224 trimspool on 
col username format a10    trunc heading "User Name"
col inst_id format 99      trunc heading "Ins|ID"
col logon_time format a11  trunc heading "Logon Time"
col machine format a12     trunc heading "Machine"
col SID_SER format a12     trunc heading "SesID,Ser#" 
col status    format a1    trunc heading "S|t|a|t|u|s"
col event format a20       trunc heading "Wait Event"
col process format a12     trunc heading "Process"
col lockwait  format a1    trunc heading "L|o|c|k|w|a|i|t"
col state format a12       trunc heading "Session|State"
col spid format a8         trunc heading "SPID"
col ppid format 999999     trunc heading "PPID"
col sql_id                       heading "Sql ID       " 
col SERVICE_NAME format a8 trunc heading "Service" 
col blocking_session format 99999 trunc heading  "Blocker"

set linesize 224 trimspool on
set pagesize 100
set heading on
set feedback on verify off echo off


select 
        s.inst_id,
        s.username,
        ' '||to_char(s.SID)||','|| to_char(s.serial#) "SID_SER",
        to_char(s.logon_time,'mm/dd hh24:mi ') logon_time,
        SUBSTR(s.status,1,1) status,
        s.service_name,
        p.pid  ppid,
        p.spid,
        s.process,
        s.sql_id,
        s.blocking_session,
        s.event,
        s.machine
from    gv$session s,
        gv$process p
where   s.paddr       =  p.addr
and     s.inst_id     =  p.inst_id
and     s.username is not null
and     s.username not in ('SYS','SYSTEM')
and     s.status ='ACTIVE'
and     s.type <> 'BACKGROUND'
order by logon_time,s.inst_id
;