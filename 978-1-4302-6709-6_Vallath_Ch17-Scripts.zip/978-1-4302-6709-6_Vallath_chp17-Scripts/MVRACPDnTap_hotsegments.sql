
-- NAME: MVRACPDnTap_hotsegments.sql
-- ------------------------------------------------------------------------
-- ------------------------------------------------------------------------
-- PURPOSE:  Script helps identify segments most often subject to Cache Buffer chain latches
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported by Summersky Enterprises.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Oracle Wait Interface A Practical Guide To Performance Diagnostics & Tuning” 
--    (2004, Oracle Press)  
--    By Richmond Shee, Kirtikumar Deshpande and K Gopalakrishnan
--

SELECT /*+ ordered */ e.owner
                      ||'.'
                      || e.segment_name         segment_name,
                      e.extent_id               extent#,
                      x.dbablk - e.block_id + 1 block#,
                      x.tch,
                      l.child#
FROM   sys.v$latch_children l,
       sys.x$bh x,
       sys.dba_extents e
WHERE  l.name = 'cache buffers chains'
       AND l.sleeps > &sleep_count
       AND x.hladdr = l.addr
       AND e.file_id = x.file#
       AND x.dbablk BETWEEN e.block_id AND e.block_id + e.blocks - 1;  