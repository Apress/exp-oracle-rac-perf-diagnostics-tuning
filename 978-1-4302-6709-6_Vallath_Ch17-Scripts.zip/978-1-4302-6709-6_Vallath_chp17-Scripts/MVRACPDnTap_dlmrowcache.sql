-- NAME: MVRACPDnTap_dlmrowcache.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    Summersky Enterprises - www.summersky.biz
--    blog - www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:  the script will list the current RAC /DLM row cache information 
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported by Summersky Enterprises.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 17 - Waits Enqueues and Latches
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks 
set pagesize 160 linesize 100 space 2 numwidth 8 verify off 
SET echo off 
col INT format 999 
column parameter format a26 
column dlm_releases format 9999, 999, 999 
column dlm_requests format 9999, 999, 999 
column dlm_conflicts format 9999, 999, 999 
col gets format 9999999999 
break ON INT skip 1 
SELECT inst_id INT, 
       parameter, 
       dlm_requests, 
       dlm_conflicts, 
       dlm_releases 
FROM   gv$rowcache 
WHERE  dlm_requests > 1000 
ORDER  BY inst_id, 
          dlm_requests desc, 
          dlm_conflicts desc;  
