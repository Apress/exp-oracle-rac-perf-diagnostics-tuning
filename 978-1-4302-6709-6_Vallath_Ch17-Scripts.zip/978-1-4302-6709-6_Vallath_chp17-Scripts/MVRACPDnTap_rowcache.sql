-- NAME: MVRACPDnTap_rowcache.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    blog - www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:  the script will list the current row cache information 
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 17 - Waits Enqueues and Latches
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set pagesize 160 linesize 100 space 2 numwidth 8 verify off
SET ECHO OFF
col int format 999
column parameter format a26
column pct_succ_gets format 99999.9
column updates format 9999,999,999
col gets format 9999999999
break on int skip 1
SELECT inst_id int
     , parameter
     , sum(gets) gets
     , sum(getmisses) misses
     , 100*sum(gets - getmisses) / sum(gets)  pct_succ_gets
     , sum(modifications)  updates
  FROM GV$ROWCACHE
 WHERE gets > 0
 HAVING sum(modifications) > 0
 GROUP BY INST_ID, parameter
 ORDER BY inst_id,
       6 desc;
SELECT inst_id int
     , parameter
     , sum(gets) gets
     , sum(getmisses) misses
     , 100*sum(gets - getmisses) / sum(gets)  pct_succ_gets
     , sum(modifications)  updates
  FROM GV$ROWCACHE
 WHERE gets > 0
 HAVING sum(modifications) > 0
 GROUP BY INST_ID, parameter
 ORDER BY inst_id,
       6 desc;