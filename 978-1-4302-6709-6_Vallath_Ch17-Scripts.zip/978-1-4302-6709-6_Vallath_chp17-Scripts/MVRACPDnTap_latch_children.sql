
-- NAME: MVRACPDnTap_latch_children.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, 
--    
--    blog - www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 17 - Waits, Enqueues & Latches
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks 
set pagesize 180 linesize 100 space 2 numwidth 8 verify off 
SET echo off 
set pagesize 400
set heading ON
set feedback ON verify OFF echo OFF
SET linesize 182 trimspool ON
COL latch# format 99999 heading "Latch"
COL level# format 99999 heading "Level"
COL INT format 999 heading "Inst"
COL gets format 99999999999 heading "Gets"
COL misses format 99999999999 heading "Misses"
COL name format a32 heading "Name of Latch"
break ON INT skip 1 
SELECT inst_id INT, 
       latch#,
       level#,
       child#  "Child", 
       addr    "Address",
       name    "Name", 
       gets    "Gets", 
       misses  "Misses", 
       sleeps  "Sleeps" 
FROM   gv$latch_children 
WHERE  misses > 1000 
ORDER  BY 1, 
          6, 
          2, 
          3;
