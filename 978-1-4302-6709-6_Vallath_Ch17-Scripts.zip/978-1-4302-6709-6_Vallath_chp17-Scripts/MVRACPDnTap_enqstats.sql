-- NAME: MVRACPDnTap_enqstats.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    blog - www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script help understand the enqueue stats from the database
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported by Summersky Enterprises.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 17 - Waits Enqueues and Latches
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--

clear breaks
set pagesize 100
set heading on
set feedback on verify off echo off
SET LINESIZE 160 trimspool on
COL REQ_REASON FORMAT A18 truncate
COL RR FORMAT A14 truncate
COL INT FORMAT 999
COL TR FORMAT 99999999
COL TW FORMAT 9999999
COL SR FORMAT 99999999
COL FR FORMAT 99999
COL CWT FORMAT 99999999
col EVENT FORMAT 999
COL EQ_NAME FORMAT A26 truncate
BREAK ON INT SKIP 1
SELECT inst_id         INT,
       eq_name,
       eq_type         EQ,
       req_reason      RR,
       total_req#      TR,
       total_wait#     TW,
       succ_req#       SR,
       failed_req#     FR,
       cum_wait_time   CWT
FROM   gv$enqueue_statistics
WHERE  total_req# > 100
ORDER  BY inst_id,
          cum_wait_time DESC;
