-- NAME: MVRACPDnTap_curdopinfo.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    URL: muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 8
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
SET ECHO OFF
COL INST FORMAT 999

SELECT px.inst_id                      INT,
       DECODE(px.qcinst_id, NULL, username,
                            ' - '
                            ||LOWER(substr(s.program, LENGTH(s.program) - 4, 4))
       )
                                       "Username",
       DECODE(px.qcinst_id, NULL, 'QC',
                            '(Slave)') "QC/Slave",
       TO_CHAR(px.server_set)          "Slave Set",
       TO_CHAR(s.sid)                  "SID",
       DECODE(px.qcinst_id, NULL, TO_CHAR(s.sid),
                            px.qcsid)  "QC SID",
       px.req_degree                   "Requested DOP",
       px.degree                       "Actual DOP",
       px.qcinst_id                    "QC Inst"
FROM   gv$px_session px,
       gv$session s
WHERE  px.inst_id = s.inst_id
       AND px.sid = s.sid (+)
       AND px.serial# = s.serial#
       AND username NOT IN ( 'SYSTEM' )
ORDER  BY 6,
          2 DESC

/  