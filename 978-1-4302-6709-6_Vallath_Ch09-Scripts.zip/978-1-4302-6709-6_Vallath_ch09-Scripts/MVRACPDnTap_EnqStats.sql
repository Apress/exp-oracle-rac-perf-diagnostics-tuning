-- NAME: MVRACPDnTap_EnqStats.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    URL: muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The query /script gives a list of the top enqueue statistics from all instances 
-- in the cluster.  It helps to understand the current enqueue activity and potential 
-- contention areas.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 09 - Tuning the Database
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set feedback off heading off linesize 132 trimspool on
select '                         ************* All Session(s) ' ||
        to_char(sysdate,'mm/dd/rr hh24:mi') ||
                               ' *************' from dual;
set pagesize 100
set heading on
set feedback on verify off echo off

SET linesize 160 trimspool ON 
COL req_reason format a18 truncate 
COL rr format a14 truncate 
COL INT format 999 
COL tr format 99999999 
COL tw format 99999999 
COL sr format 99999999 
COL fr format 99999 
COL cwt format 99999999 
col event format 999 
COL description format a38 truncate 
COL eq_name format a16 truncate 
BREAK ON INT skip 1 
SELECT inst_id       INT, 
       eq_type       eq, 
       eq_name, 
       total_req#    tr, 
       total_wait#   tw, 
       succ_req#     sr, 
       failed_req#   fr, 
       cum_wait_time cwt 
FROM   gv$enqueue_statistics 
WHERE  total_req# > 1000 
       AND cum_wait_time > 0 
       AND eq_type IN ( 'TX', 'TM', 'SQ' ) 
ORDER  BY inst_id, 
          total_req# DESC, 
          total_wait# DESC, 
          cum_wait_time DESC;  
