-- NAME: MVRACPDnTap_rcutil.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The query gives the current result cache statistics.  It gives the 
-- current space utilization of the results section of the operation.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 09 - Tuning the Database
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR BREAKS
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
COL INT format 999 
COL blkcnt format 999999 
COL rcnt format 9999 
COL invals format 9999 
COL objno format 99999 
COL rsm format 9999 
COL rsa format 9999 
COL soh format 9999 
COL sun format 9999 
COL clmcnt format 999999 
SELECT inst_id        INT, 
       id, 
       TYPE, 
       block_count    blkcnt, 
       column_count   clmcnt, 
       scan_count, 
       row_count      rcnt, 
       row_size_max   rsm, 
       row_size_avg   rsa, 
       space_overhead soh, 
       space_unused   sun 
FROM   gv$result_cache_objects 
WHERE  inst_id = &&instnum; 

 
