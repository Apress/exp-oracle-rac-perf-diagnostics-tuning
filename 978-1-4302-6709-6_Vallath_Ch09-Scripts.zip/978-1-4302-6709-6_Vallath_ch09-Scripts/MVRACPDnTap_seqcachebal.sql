-- NAME: MVRACPDnTap_seqcachebal.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- When monitoring the cache size requirements for database sequences. The script helps 
-- to understand how frequently the database sequences are consumed and how often they 
-- have to reloaded.  Helps to size the cache size and to understand the contentions when 
-- the database sequences are defined with the order clause
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 09 - Tuning the Database
--    Oracle 11g Testing & Tuning RAC by Murali Vallath
--    Publisher: Oracle Press, 2011
--
clear breaks 
set pagesize 160 space 2 numwidth 8 linesize 100 verify off 
SET echo off 
col INT format 999 
COL sname format a20 heading "Seq. | Name" 
COL sowner format a8 heading "Seq. |Owner" 
COL ilf format 999 heading "Inst.|Lock" 
COL bil format 999 noprint 
COL cache_size format 99999 heading "Cache |Size" 
COL nextvalue heading "Next | Value" 
COL highwater heading "Highwater" 
COL balancecache heading "Bal. |Cache" 
COL active_flag format a1 noprint 
COL ord format a1 heading "Order|By" 
break ON INT skip 1 
SELECT inst_id                  INT, 
       sequence_owner           sowner, 
       sequence_name            sname, 
       cache_size, 
       nextvalue, 
       highwater, 
       highwater - nextvalue    balancecache, 
       background_instance_lock bil, 
       instance_lock_flags      ilf, 
       active_flag, 
       order_flag 
FROM   gv$_sequences 
WHERE  sequence_owner NOT IN ( 'SYS', 'SYSMAN', 'SYSTEM', 'DBSNMP' ) 
ORDER  BY inst_id, 
          sequence_owner;  
		  

