-- NAME: MVRACPDnTap_dlmrowcache.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    blog - www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The primary difference between the two is from what level is the data reported.  
-- This query reports data from a RAC level, across instances and reflects cache fusion 
-- activity.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 09 - Tuning the Database
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set pagesize 160 linesize 100 space 2 numwidth 8 verify off
SET ECHO OFF
col int format 999
column parameter format a26
column releases format 9999,999,999
column conflicts format 9999,999,999
column requests format 9999,999,999
break on int skip 1
SELECT inst_id int
     , parameter
     , sum(dlm_requests) requests
     , sum(dlm_conflicts) conflicts
     , sum(dlm_releases)  releases
  FROM GV$ROWCACHE
 WHERE gets > 0
 HAVING sum(dlm_releases) > 0
 GROUP BY INST_ID, parameter
 ORDER BY inst_id,
       5 desc;
