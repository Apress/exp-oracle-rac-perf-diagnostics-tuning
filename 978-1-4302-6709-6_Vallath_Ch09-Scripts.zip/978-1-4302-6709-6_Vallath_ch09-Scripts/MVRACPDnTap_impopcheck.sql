-- NAME: MVRACPDnTap_impopcheck.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath,  Consultant
--  www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- scripts lists the segment statistics of the in-memory area
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 09 - Tuning the Database
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR breaks
set pagesize 60 SPACE 2 numwidth 8 linesize 132 verify OFF
COL INT format 999
COL owner format a10
COL segname format a10
COL segtype format a10
SELECT ims.inst_id                   INT,
       ims.owner                     OWNER,
       ims.segment_name              SEGNAME,
       ims.segment_type              SEGTYPE,
       ims.populate_status           STATUS,
       ims.inmemory_priority         PRIORITY,
       ims.inmemory_distribute       DISTRIBUTE,
       ims.inmemory_duplicate        DUPLICATE,
       ims.inmemory_compression      COMPRESSD,
       ims.bytes / ims.inmemory_size comp_ratio
FROM   gv$im_segments ims;  