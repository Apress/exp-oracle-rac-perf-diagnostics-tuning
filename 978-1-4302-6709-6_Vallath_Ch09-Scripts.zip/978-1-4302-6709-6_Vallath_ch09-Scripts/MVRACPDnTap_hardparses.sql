-- NAME: MVRACPDnTap_hardparses.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script gives a count of the total number of hard parse operations from the database
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 09 - Tuning the Database
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks
set pagesize 60 space 2 numwidth 8 linesize 100 verify off
SET ECHO OFF
SELECT pa.inst_id, 
       pa.sid, 
       pa.VALUE "Hard Parses", 
       ex.VALUE "Execute Count" 
FROM   gv$sesstat pa, 
       gv$sesstat ex 
WHERE  pa.sid = ex.sid 
       AND pa.inst_id = ex.inst_id 
       AND pa.statistic# = (SELECT statistic# 
                            FROM   v$statname 
                            WHERE  NAME = 'parse count (hard)') 
       AND ex.statistic# = (SELECT statistic# 
                            FROM   v$statname 
                            WHERE  NAME = 'execute count') 
       AND pa.VALUE > 0;  


