-- NAME: MVRACPDnTap_rcobjects.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The query gives a list of objects involved in a result cache operation.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 09 - Tuning the Database
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR BREAKS
set pagesize 60 space 2 numwidth 8 linesize 132 verify off
COL INT format 999
SELECT inst_id       INT, 
       id, 
       TYPE, 
       status, 
       NAME, 
       object_no     objno, 
       cache_id, 
       invalidations invals 
FROM   gv$result_cache_objects 
WHERE  inst_id = &&instnum;  
 
