-- NAME: MVRACPDnTap_rcobjectcount.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script gives a list of objects currently stored in the result cache section 
-- of the shared pool.
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 09 - Tuning the Database
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
CLEAR breaks 
set pagesize 60 space 2 numwidth 8 linesize 132 verify off 
COL INT format 999 
COL blkcnt format 999999 
COL rcnt format 9999 
COL invals format 9999 
COL objno format 99999 
COL rsm format 9999 
COL rsa format 9999 
COL soh format 9999 
COL sun format 9999 
COL clmcnt format 999999 
SELECT inst_id INT, 
       id, 
       TYPE, 
       creation_timestamp, 
       block_count, 
       column_count, 
       pin_count, 
       row_count 
FROM   gv$result_cache_objects 
WHERE  inst_id = &&instnum;  
