-- NAME: MVRACPDnTap_ashbysqlid.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath, Independent Oracle Consultant
--    blog - www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 9 - Tuning the Database
--    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--

COL p1text format a14
COL p2text format a14
COL p3text format a14
COL event format a30
COL wait_class format a18
SELECT inst_id,
       event,
       p1,
       p2,
       wait_class
FROM   gv$active_session_history
WHERE  sql_id = &&sqlid
       AND event IS NOT NULL
ORDER  BY p2,
          p1;
