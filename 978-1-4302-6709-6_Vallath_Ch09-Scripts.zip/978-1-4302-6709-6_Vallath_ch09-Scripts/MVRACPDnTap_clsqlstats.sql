-- NAME: MVRACPDnTap_clsqlstats.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath,  Consultant
--    Blog: muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- The script gives cluster level stats for a SQL Statement
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 9 - Tuning the Database
—-    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks 
set pagesize 160 linesize 100 space 2 numwidth 8 verify off 
SET echo off 
col INT format 999 
col SQL_ID format a16 
break ON INT skip 1 
SELECT inst_id               INT,
       sql_id,
       application_wait_time awt,
       concurrency_wait_time conwt,
       cluster_wait_time     clwt,
       io_interconnect_bytes ioicbytes
FROM   gv$sqlstats
WHERE  cluster_wait_time > 10000
ORDER  BY inst_id,
          user_io_wait_time DESC;