-- NAME: MVRACPDnTap_enableAgg.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    URL : muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 6 - Tools and Utilities
—-    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks 
set pagesize 160 linesize 100 space 2 numwidth 8 verify off 
SET echo off 
COL AGGREGATION_TYPE FORMAT A20
COL MODULE FORMAT A20
COL ACTION FORMAT A30
SELECT AGGREGATION_TYPE,
       QUALIFIER_ID1 MODULE,
       QUALIFIER_ID2 ACTION
FROM DBA_ENABLED_AGGREGATIONS;

