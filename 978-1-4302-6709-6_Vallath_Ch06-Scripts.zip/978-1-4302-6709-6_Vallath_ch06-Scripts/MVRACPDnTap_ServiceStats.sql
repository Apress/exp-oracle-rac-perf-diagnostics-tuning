
-- NAME: MVRACPDnTap_ServiceStats.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    www.muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- Script lists database service stats The script helps to isolate top activity on the 
-- database by service name
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. 
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 6 - Tools and Utilities
—-    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks 
set pagesize 160 linesize 100 space 2 numwidth 8 verify off 
SET echo off 
col INT format 999
break ON INT skip 1
COL STAT_NAME FORMAT A35
COL MODULE FORMAT A10
COL SERVICE FORMAT A15
COL VALUE FORMAT 99999999999999
SELECT INST_ID INT, 
       SERVICE_NAME SERVICE,
       STAT_NAME,
       VALUE 
FROM   GV$SERVICE_STATS 
WHERE  VALUE > 0 
AND    SERVICE_NAME ='TAPS' 
ORDER  BY INST_ID,VALUE;

