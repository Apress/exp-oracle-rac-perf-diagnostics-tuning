-- NAME: MVRACPDnTap_ServModActStats.sql
-- ------------------------------------------------------------------------
-- AUTHOR:
--    Murali Vallath
--    muralivallath.com
-- ------------------------------------------------------------------------
-- PURPOSE:
-- 
-- ------------------------------------------------------------------------
-- DISCLAIMER:
--    This script is provided for illustration/example purposes only. It 
--    is NOT supported by Summersky Enterprises.
--
--    The script has been tested and appears to work as intended.
--    You should always run new scripts on a test instance initially.
-- ------------------------------------------------------------------------
-- SOURCE:
--    Chapter 6 - Tools and Utilities
—-    Expert Oracle RAC Performance Diagnostics and Tuning (ISBN 978-1-4302-6709-6)
--    by Murali Vallath
--    Publisher: APress, 2014
--
clear breaks 
set pagesize 160 linesize 100 space 2 numwidth 8 verify off 
SET echo off 
col INT format 999
break ON INT skip 1
COL STAT_NAME FORMAT A35
COL MODULE FORMAT A10
COL SERVICE FORMAT A10
COL ACTION FORMAT A8
SELECT INST_ID INT,
       AGGREGATION_TYPE,
       SERVICE_NAME SERVICE,
       MODULE,
       ACTION,
       STAT_NAME,
       VALUE 
FROM  GV$SERV_MOD_ACT_STATS
WHERE VALUE > 0
ORDER BY INST_ID,VALUE DESC;

